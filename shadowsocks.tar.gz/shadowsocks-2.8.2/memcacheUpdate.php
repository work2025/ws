<?php
/*系统配置*/
// nohup php /root/shadowsocks-2.8.2/memcacheUpdate.php >> /root/shadowsocks-2.8.2/sql.log 2>&1 &
ini_set('memory_limit','-1');
//单一键值存储数据过大会有问题
class MEM
{
    public $mem;
    function __construct(){
        $this->mem = new Memcached();
        $this->mem->addServer('127.0.0.1', 11211);
    }
    public function __call($name,$args){
        return call_user_func_array([$this->mem, $name], $args);
    }
}
class updateUserInfo
{
    // config
    public $config;
    public $users;
    //数据库连接
    public $database = null;
    public $mem;
    public function __construct()
    {
        $this->config = array(
            'db_type' => 'mysql',
            'db_host' => '61.14.254.190',//登陆地址
            'db_user' => 'ssproxy',//登陆用户名
            'db_pass' => 'fuck%#!GFW~kitty',//登陆密码
            'db_name' => 'ss',//用户数据库名字
            'db_persist' => '0',
            'db_port' => '3306',
        );
    }
    /**
     * 保持tcp/ip连接存活,如果已经丢失则重连
     * @return void
     */
    public function keepAlive()
    {
        $db = $this->config;
        if ( !$this->database || !mysqli_ping($this->database) ) {
            $this->database = @mysqli_connect($db['db_host'], $db['db_user'], $db['db_pass'],$db['db_name'],$db['db_port']);
            mysqli_query($this->database,'set names utf8');
        }
    }
    //uploaded,downloaded,isClosed
    public function getUserFromMemcached(){
        $this->keepAlive();
        $mem        = new MEM();
        $user_data  = [];
        $mem_aff    = $mem->getAllKeys();
        $affs       = array_values($mem_aff);
        $updated_aff= [];
        if( !empty($affs) ){
            $u = $d = '';
            $sql        = "UPDATE ss_user";
            foreach( $affs as $aff ){//更新用户流量
                $aff    = (int)$aff;
                $user   = $mem->get($aff);
				$user	= json_decode($user,true);
                $uploaded   = isset($user['uploaded'])?(int)$user['uploaded']:0;
                $downloaded = isset($user['downloaded'])?(int)$user['downloaded']:0;
                if( $uploaded || $downloaded ) {
                    $uploaded && $u .= " WHEN {$aff} THEN `u`+{$uploaded}";
                    $downloaded && $d .= " WHEN {$aff} THEN `d`+{$downloaded}";
                    $updated_aff[] = $aff;
                }
                $user_data[$aff]['uploaded']=$user_data[$aff]['downloaded']=0;
            }
            $now = time();
            if( $u!='' && $d!='' ){
                $sql .= " SET `u`=CASE aff $u END";
                $sql .= ",`d`=CASE aff $d END,t={$now} WHERE aff IN(".join(',',$updated_aff).")";

                mysqli_query($this->database,$sql);
                echo date('Y-m-d H:i:s',time())."\t".$sql."\n";
				//当日签到送20兆
				/*
				$sql	= "SELECT * FROM ss_user_sign WHERE aff IN(".join(',',$updated_aff).")";
				$query	= mysqli_query($this->database,$sql);
				$today  = strtotime(date('Y-m-d'));
				$sign_today = [];
				while ( $row = mysqli_fetch_assoc($query) ) {
					if( $row['sign_time']>$today ){
						$sign_today[$row['aff']] = 1;
					}
				}
				*/
                $sql	= "SELECT * FROM ss_user WHERE aff IN(".join(',',$updated_aff).")";
                $query	= mysqli_query($this->database,$sql);
                $aff_db = [];
                while ($row = mysqli_fetch_assoc($query)) {
                    //关闭用户
                    $aff        = $row['aff'];
                    $aff_db[]   = $row['aff'];
					if( isset($sign_today[$aff]) ){
						$row['transfer_enable'] += 20971520;
					}
                    if( ($row['u']+$row['d'])>$row['transfer_enable'] || $row['enable']<1 ){
                        $user_data[$aff]['isClosed']	= 1;
                        $mem->set($aff,json_encode($user_data[$aff]),(time()+1800));//缓存
                    }else{
                        $mem->set($aff,json_encode($user_data[$aff]),(time()+600));//缓存
                    }
                }
                foreach ($updated_aff as $aff){//数据库中没有这个 aff 记录
                    if( !in_array($aff,$aff_db) ){
                        $user_data[$aff]['isClosed']	= 1;
                        $mem->set($aff,json_encode($user_data[$aff]),(time()+1800));//缓存
                    }
                }
            }
        }
    }
}
date_default_timezone_set('PRC');
while(1){
    $obj = new updateUserInfo();
    $obj->getUserFromMemcached();
    sleep(180);
}
?>
